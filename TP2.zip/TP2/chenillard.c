#include <linux/module.h>
#include <linux/kernel.h>
#include <linux/init.h>
#include <linux/proc_fs.h>
#include <linux/uaccess.h>
#include <linux/timer.h>

#define PROCFS_NAME "ensea/chenille"
#define BUF_LEN 128

static char pattern[BUF_LEN] = "10101010";
static unsigned long vitesse = 500;
static struct timer_list my_timer;
static struct proc_dir_entry *proc_entry;

module_param(vitesse, ulong, 0644);
MODULE_PARM_DESC(vitesse, "Vitesse du chenillard (en ms)");

static void timer_callback(unsigned long data)
{
    printk(KERN_INFO "Chenillard: pattern = %s\n", pattern);
    mod_timer(&my_timer, jiffies + msecs_to_jiffies(vitesse));
}

static ssize_t write_proc(struct file *file, const char __user *buffer, size_t count, loff_t *ppos)
{
    if (count >= BUF_LEN)
        return -EINVAL;

    if (copy_from_user(pattern, buffer, count))
        return -EFAULT;

    pattern[count] = '\0';
    printk(KERN_INFO "Nouveau pattern : %s\n", pattern);
    return count;
}

static const struct file_operations proc_fops = {
    .owner = THIS_MODULE,
    .write = write_proc,
};

static int __init chenillard_init(void)
{
    proc_entry = proc_create(PROCFS_NAME, 0666, NULL, &proc_fops);
    if (!proc_entry) {
        printk(KERN_ERR "Erreur creation /proc/%s\n", PROCFS_NAME);
        return -ENOMEM;
    }

    init_timer(&my_timer);
    my_timer.function = timer_callback;
    my_timer.data = 0;
    mod_timer(&my_timer, jiffies + msecs_to_jiffies(vitesse));

    printk(KERN_INFO "Module chenillard chargé\n");
    return 0;
}

static void __exit chenillard_exit(void)
{
    del_timer_sync(&my_timer);
    proc_remove(proc_entry);
    printk(KERN_INFO "Module chenillard retiré\n");
}

MODULE_LICENSE("GPL");
MODULE_AUTHOR("Toi");
MODULE_DESCRIPTION("Chenillard noyau modifiable par /proc");

module_init(chenillard_init);
module_exit(chenillard_exit);
