#include <stdio.h>
#include<stdlib.h>
#include<string.h>
 
int main(void){
    printf("Hello world\n");
    return 0;
}