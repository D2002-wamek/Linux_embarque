# Linux_embarque
TP Linux embarqué
